# Terminal Prep

Run this once on each Windows workstation or utility server that will run client workflows. Run it again when tools need an update.

1. Extract Terminal-Prep.zip.
2. Open Windows PowerShell under the Windows account you use for workflows. Run as a local administrator if PowerShell 7 or RSAT needs to be installed. From the extracted folder, run `.\TERMINAL-PREP.ps1`.
3. Approve PowerShell setup. Choose 3 for both Microsoft 365 modules and Active Directory tools. The wizard checks versions and installs missing or outdated Microsoft 365 tools.
4. Enter an approved client tenant ID and Microsoft 365 administrator UPN. Sign in through Microsoft prompts. Graph and Exchange run a read-only organization check against the expected tenant. Use an authorized account with the required read access and approved Graph consent.
5. Review PASS, FAIL, or SKIP. Press Enter when finished. READY means all selected checks passed. Follow any remediation and rerun. If Windows requires a restart, restart through your approved process first.

The report shows PowerShell and module versions. Windows servicing manages the AD tools. AD PASS means the module loaded locally. Graph and Exchange PASS apply to the tested tenant and read operations. Tenant access can be skipped for local prep.

Review build. Validate first on a Windows test machine and a test tenant.
