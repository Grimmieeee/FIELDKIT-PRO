#Requires -Version 5.1
[CmdletBinding()]
param([switch]$ModuleStage)

$ErrorActionPreference = 'Stop'
$results = [Collections.Generic.List[object]]::new()

function Write-Result {
    param([string]$Check, [string]$Status, [string]$Detail)
    $results.Add([pscustomobject]@{ Check = $Check; Status = $Status; Detail = $Detail })
    Write-Host "[$Status] $Check - $Detail"
}

function Test-LocalAdministrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = [Security.Principal.WindowsPrincipal]::new($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Get-CurrentPowerShell {
    [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
    $release = Invoke-RestMethod -Uri 'https://api.github.com/repos/PowerShell/PowerShell/releases/latest' -TimeoutSec 30
    $tag = [regex]::Match([string]$release.tag_name, '^v(7\.\d+\.\d+)$')
    if ($release.draft -or $release.prerelease -or -not $tag.Success) {
        throw 'The stable PowerShell 7 release could not be identified.'
    }
    $latest = [version]$tag.Groups[1].Value
    $candidate = Join-Path $env:ProgramFiles 'PowerShell\7\pwsh.exe'
    $running = $PSVersionTable.PSVersion
    if ($running.Major -eq 7 -and -not $running.PreReleaseLabel -and $running -ge $latest) {
        $candidate = Join-Path $PSHOME 'pwsh.exe'
    }
    $installed = if (Test-Path -LiteralPath $candidate -PathType Leaf) {
        $versionText = & $candidate -NoProfile -NonInteractive -Command '[Console]::Write($PSVersionTable.PSVersion.ToString())'
        if ($LASTEXITCODE -ne 0) { throw 'Installed PowerShell 7 could not start.' }
        $versionText -as [version]
    }

    if ($installed -and $installed -ge $latest) {
        Write-Result 'PowerShell' 'PASS' "Installed $installed, stable release $latest."
        return $candidate
    }

    if (-not (Test-LocalAdministrator)) {
        throw 'Open Windows PowerShell as a local administrator and rerun Terminal Prep to install PowerShell 7.'
    }
    $architecture = [Runtime.InteropServices.RuntimeInformation]::OSArchitecture.ToString().ToLowerInvariant()
    if ($architecture -notin @('x64','arm64','x86')) { throw "Unsupported Windows architecture: $architecture." }
    $filename = "PowerShell-$latest-$architecture.msi"
    $assetUrl = "https://github.com/PowerShell/PowerShell/releases/download/v$latest/$filename"
    if (@($release.assets | Where-Object { $_.name -eq $filename -and $_.browser_download_url -ceq $assetUrl }).Count -ne 1) {
        throw 'The matching Microsoft MSI could not be found. Use your approved software deployment process.'
    }

    $tempDirectory = Join-Path ([IO.Path]::GetTempPath()) ([guid]::NewGuid().ToString())
    New-Item -ItemType Directory -Path $tempDirectory | Out-Null
    $msi = Join-Path $tempDirectory $filename
    try {
        Write-Host "Downloading Microsoft PowerShell $latest for $architecture..."
        Invoke-WebRequest -Uri $assetUrl -UseBasicParsing -OutFile $msi -TimeoutSec 180
        $signature = Get-AuthenticodeSignature -LiteralPath $msi
        if ($signature.Status -ne 'Valid' -or $signature.SignerCertificate.GetNameInfo('SimpleName',$false) -ne 'Microsoft Corporation') {
            throw 'Microsoft signature validation failed. The installer was not run.'
        }
        Write-Host 'Installing PowerShell 7. Windows may take a few minutes.'
        $process = Start-Process -FilePath (Join-Path $env:SystemRoot 'System32\msiexec.exe') -ArgumentList "/i `"$msi`" /passive /norestart" -Wait -PassThru
        if ($process.ExitCode -eq 3010) { throw 'PowerShell installed and requires a restart. Restart through your approved process, then rerun.' }
        if ($process.ExitCode -ne 0) { throw "PowerShell installer exit code $($process.ExitCode). Check Windows Installer logs and retry." }
    } finally {
        Remove-Item -LiteralPath $tempDirectory -Recurse -Force -ErrorAction SilentlyContinue
    }

    if (-not (Test-Path -LiteralPath $candidate -PathType Leaf)) { throw 'The installed PowerShell executable could not be found.' }
    $verified = & $candidate -NoProfile -NonInteractive -Command '[Console]::Write($PSVersionTable.PSVersion.ToString())'
    if ($LASTEXITCODE -ne 0 -or ($verified -as [version]) -lt $latest) {
        throw 'The installed PowerShell version could not be verified. Close other PowerShell windows and rerun.'
    }
    Write-Result 'PowerShell' 'PASS' "Installed and launched $verified."
    return $candidate
}

function Install-CurrentModule {
    param([string]$Name)
    $gallery = Get-PSRepository -Name PSGallery
    if ($gallery.SourceLocation -notmatch '^https://www\.powershellgallery\.com/api/v2/?$') {
        throw 'PSGallery is not the official HTTPS source. Ask the workstation owner to restore the approved repository.'
    }

    $target = [version](Find-Module -Name $Name -Repository PSGallery).Version
    $module = Get-Module -Name $Name -ListAvailable | Sort-Object Version -Descending | Select-Object -First 1
    if (-not $module -or $module.Version -lt $target) {
        Write-Host "Installing $Name $target for $env:USERNAME..."
        Install-Module -Name $Name -RequiredVersion $target -Repository PSGallery -Scope CurrentUser -Force
        $module = Get-Module -Name $Name -ListAvailable | Sort-Object Version -Descending | Select-Object -First 1
    }
    if (-not $module -or $module.Version -lt $target) { throw "$Name $target was not found after installation." }
    if ($Name -eq 'Microsoft.Graph') {
        Import-Module Microsoft.Graph.Authentication -RequiredVersion $module.Version
    } else {
        Import-Module -Name $Name -RequiredVersion $module.Version
    }
    Write-Result $Name 'PASS' "Installed $($module.Version), Gallery $target."
}

function Install-ActiveDirectoryTools {
    if (-not (Get-Module ActiveDirectory -ListAvailable)) {
        if (-not (Test-LocalAdministrator)) { throw 'Rerun Terminal Prep elevated under the same Windows account to install RSAT.' }
        $installer = @'
$ErrorActionPreference = 'Stop'
try {
    if ((Get-CimInstance Win32_OperatingSystem).ProductType -eq 1) {
        $result = Add-WindowsCapability -Online -Name 'Rsat.ActiveDirectory.DS-LDS.Tools~~~~0.0.1.0'
    } else {
        $result = Install-WindowsFeature -Name RSAT-AD-PowerShell
        if (-not $result.Success) { throw 'Windows Server reported an RSAT installation failure.' }
    }
    if ([string]$result.RestartNeeded -in @('True','Yes','Maybe')) { exit 3010 }
    exit 0
} catch {
    Write-Host $_.Exception.Message
    exit 1
}
'@
        Write-Host 'Installing Active Directory tools through Windows servicing...'
        $encoded = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($installer))
        & (Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe') -NoProfile -NonInteractive -EncodedCommand $encoded
        if ($LASTEXITCODE -eq 3010) { throw 'Windows reports a restart is required. Restart, then rerun Terminal Prep.' }
        if ($LASTEXITCODE -ne 0) { throw 'RSAT installation failed. Check Windows servicing policy and the error above.' }
    }
    $module = Import-Module ActiveDirectory -PassThru
    if (-not $module.ExportedCommands.ContainsKey('Get-ADDomain')) { throw 'The AD module did not load Get-ADDomain.' }
    Write-Result 'Active Directory tools' 'PASS' "Module $($module.Version) loaded. Windows servicing supplies updates."
}

function Test-TenantAccess {
    param([string]$Selection)
    [guid]$tenant = [guid]::Empty
    if (-not $results.Where({$_.Check -in @('Microsoft.Graph','ExchangeOnlineManagement') -and $_.Status -eq 'PASS'}).Count) {
        Write-Result 'Client tenant access' 'SKIP' 'Repair the module checks before signing in.'
        return
    }
    $tenantInput = (Read-Host 'Enter the approved client tenant ID (GUID), or Enter to skip sign-in').Trim()
    if (-not $tenantInput) {
        Write-Result 'Client tenant access' 'SKIP' 'Sign-in skipped. Local setup and tenant access are separate checks.'
        return
    }
    if (-not [guid]::TryParse($tenantInput,[ref]$tenant) -or $tenant -eq [guid]::Empty) {
        Write-Result 'Client tenant access' 'FAIL' 'Use the tenant ID from the approved client record.'
        return
    }

    Write-Host 'Use only the approved tenant and account. Continue through approved sign-in and consent prompts.'
    $account = (Read-Host 'Enter the approved M365 administrator sign-in address').Trim()
    if ($account -notmatch '^[^@\s]+@[^@\s]+$') {
        Write-Result 'Client tenant access' 'FAIL' 'Enter an administrator UPN for the approved client.'
        return
    }

    if ($Selection -in @('1','3') -and $results.Where({$_.Check -eq 'Microsoft.Graph' -and $_.Status -eq 'PASS'}).Count) {
        try {
            Connect-MgGraph -TenantId $tenant -Scopes 'Organization.Read.All' -ContextScope Process -NoWelcome | Out-Null
            $context = Get-MgContext
            if ($context.TenantId -ne $tenant.ToString() -or $context.Account -ine $account) {
                throw 'The Graph sign-in did not match the selected tenant and account.'
            }
            $organization = Invoke-MgGraphRequest -Method GET -Uri 'https://graph.microsoft.com/v1.0/organization?$select=id'
            if (@($organization.value | Where-Object id -EQ $tenant.ToString()).Count -ne 1) { throw 'The organization read did not confirm the selected tenant.' }
            Write-Result 'Graph client access' 'PASS' 'Read the expected organization.'
        } catch {
            Write-Result 'Graph client access' 'FAIL' "$($_.Exception.Message) Confirm the account, tenant, and approved Organization.Read.All consent."
        } finally {
            if (Get-MgContext) { Disconnect-MgGraph -ErrorAction SilentlyContinue | Out-Null }
        }
    }

    if ($Selection -in @('2','3') -and $results.Where({$_.Check -eq 'ExchangeOnlineManagement' -and $_.Status -eq 'PASS'}).Count) {
        try {
            Connect-ExchangeOnline -UserPrincipalName $account -CommandName Get-OrganizationConfig -ShowBanner:$false
            $connections = @(Get-ConnectionInformation)
            if ($connections.Count -ne 1 -or $connections[0].TenantID -ne $tenant.ToString() -or $connections[0].UserPrincipalName -ine $account) {
                throw 'The Exchange sign-in did not match the selected tenant and account.'
            }
            if (-not (Get-OrganizationConfig)) { throw 'Exchange returned no organization configuration.' }
            Write-Result 'Exchange client access' 'PASS' 'Read organization configuration in the expected tenant.'
        } catch {
            Write-Result 'Exchange client access' 'FAIL' "$($_.Exception.Message) Check the tenant, sign-in, and Exchange read role."
        } finally {
            Disconnect-ExchangeOnline -Confirm:$false -ErrorAction SilentlyContinue | Out-Null
        }
    }
}

if (-not $ModuleStage) {
    try {
        if ($env:OS -ne 'Windows_NT') { throw 'Run Terminal Prep on Windows.' }
        if (-not [Environment]::Is64BitProcess -and [Environment]::Is64BitOperatingSystem) {
            throw 'Start Terminal Prep from a native 64-bit PowerShell window.'
        }
        Write-Host 'TERMINAL PREP | PowerShell and client tools'
        Write-Host "Computer $env:COMPUTERNAME | Windows user $env:USERNAME"
        if ((Read-Host 'Review and install PowerShell updates if needed? [y/N]') -ine 'y') { return }
        $pwsh = Get-CurrentPowerShell
        & $pwsh -NoProfile -File $PSCommandPath -ModuleStage
        exit $LASTEXITCODE
    } catch {
        Write-Result 'PowerShell' 'FAIL' $_.Exception.Message
        [void](Read-Host 'Press Enter to close')
        exit 1
    }
}

try {
    if ($env:OS -ne 'Windows_NT' -or $PSVersionTable.PSVersion.Major -ne 7) { throw 'Start TERMINAL-PREP.ps1 without arguments from Windows.' }
    Write-Result 'PowerShell' 'PASS' "Running $($PSVersionTable.PSVersion) in a fresh session."
    Write-Host '1. Microsoft Graph'
    Write-Host '2. Exchange Online'
    Write-Host '3. Both Microsoft 365 modules and Active Directory tools'
    $selection = (Read-Host 'Choose 1, 2, or 3').Trim()
    if ($selection -notin @('1','2','3')) { throw 'Choose 1, 2, or 3 and rerun Terminal Prep.' }
    $modules = switch ($selection) {
        '1' { 'Microsoft.Graph' }
        '2' { 'ExchangeOnlineManagement' }
        '3' { 'Microsoft.Graph'; 'ExchangeOnlineManagement' }
    }
    foreach ($name in $modules) {
        try { Install-CurrentModule $name }
        catch { Write-Result $name 'FAIL' "$($_.Exception.Message) Check PowerShell Gallery access and retry." }
    }
    if ($selection -eq '3') {
        try { Install-ActiveDirectoryTools }
        catch { Write-Result 'Active Directory tools' 'FAIL' $_.Exception.Message }
    }
    Test-TenantAccess $selection
} catch {
    Write-Result 'Terminal Prep' 'FAIL' $_.Exception.Message
}

$results | Format-Table -AutoSize -Wrap | Out-Host
if ($results.Status -contains 'FAIL') { Write-Host 'ACTION REQUIRED. Review failed checks and rerun after remediation.' }
elseif ($results.Status -contains 'SKIP') { Write-Host 'LOCAL SETUP COMPLETE. Client access still needs verification.' }
else { Write-Host 'READY. All selected checks passed.' }
[void](Read-Host 'Press Enter to complete')
if ($results.Status -contains 'FAIL') { exit 1 }
if ($results.Status -contains 'SKIP') { exit 2 }
exit 0
